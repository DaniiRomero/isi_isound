﻿using MuMaps.Helpers;
using MuMaps.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static MuMaps.Models.SpotityArtistTracksSearch;

namespace MuMaps
{
    /// <summary>
    /// Lógica de interacción para MyPlaylist.xaml
    /// </summary>
    public partial class MyPlaylist : Window
    {
        private List<SpotifyArtist> listaArtistas;
        private List<SpotifyTrack> listaCanciones = new List<SpotifyTrack>();
        private List<String> listafiltroart = new List<String>();
        private int contfiltroart = 0;
        private MyTravels win;


        public MyPlaylist()
        {
            InitializeComponent();
        }
        private void topTracks()
        {
            
            SpotifyArtistTracksResult result = null;
            if (check_idArtist() && contfiltroart <5)
            {     
                result = SearchHelper.SearchTracks(listaArtistas[lst_Artistas.SelectedIndex].ID);   
                listafiltroart.Add(listaArtistas[lst_Artistas.SelectedIndex].Name);
                contfiltroart++;
            }
            else
            {
                return;
            }

            if (result == null)
            {
                return;
            }
            lst_Category.ItemsSource = null;
            foreach (var item in result.tracks)
            {
                
                listaCanciones.Add(new SpotifyTrack()
                {
                    nombre = item.name
                });
            }
            lst_Category.ItemsSource = listaCanciones;
        }

        private bool check_idArtist()
        {
            if (lst_Artistas.SelectedIndex>=0)
            {
                return true;
            }
            else
                return false;
        }

        private void tbx_Artista_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbx_busArtista.Text == string.Empty)
            {
                lst_Artistas.ItemsSource = null;
                return;
            }

            var result = SearchHelper.SearchArtist(tbx_busArtista.Text);

            if (result == null)
            {
                return;
            }

            listaArtistas = new List<SpotifyArtist>();

            foreach (var item in result.artists.items)
            {
                
                listaArtistas.Add(new SpotifyArtist()
                {
                    ID = item.id,
                    Image = item.images.Any() ? item.images[0].url : "https://user-images.githubusercontent.com/24848110/33519396-7e56363c-d79d-11e7-969b-09782f5ccbab.png",
                    Name = item.name,
                    Followers = $"{item.followers.total.ToString("N")} seguidores"
                });
            }

            lst_Artistas.ItemsSource = listaArtistas;
        }

        private void btnVolver_Click(object sender, RoutedEventArgs e)
        {
            win = new MyTravels();
            win.Show();
            this.Close();
        }

        private void ck_artista_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ck_Category_Checked(object sender, RoutedEventArgs e)
        {
            var result = SearchHelper.SearchCategories();

            if (result == null)
            {
                return;
            }

            var listaCategorias = new List<SpotifyGenre>();

            foreach (var item in result.categories.items)
            {
                foreach (var item2 in item.icons)
                {
                    listaCategorias.Add(new SpotifyGenre()
                    {
                        id = item.id,
                        url= item2.url,
                        nombre = item.name,
                    });
                }
            }

            lst_Category.ItemsSource = listaCategorias;
        }

        private void lst_Artistas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            topTracks();
            filtroArtistas();
        }
        private void filtroArtistas()
        {
            //tbx_filtroArtista.Text = String.Empty;
            foreach (var artista in listafiltroart)
            {
                //tbx_filtroArtista.Text += artista.ToString() + "  ";
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void tbx_busAlbum_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void tbx_busArtista_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
