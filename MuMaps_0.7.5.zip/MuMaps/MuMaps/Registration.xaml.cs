﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace MuMaps
{
    /// <summary>
    /// Lógica de interacción para Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        XmlDocument doc = new XmlDocument();   
        public Registration()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AñadirXML();
            this.Close();
        }

        private void AñadirXML()
        {
            doc.Load("listaUsuario.xml");

            XmlNode Users = crearUsuario();
            XmlNode nodoRaiz = doc.DocumentElement;
            nodoRaiz.InsertAfter(Users,nodoRaiz.LastChild);

            doc.Save("listaUsuario.xml");

        }

        private XmlNode crearUsuario()
        {
            Models.Usuario nuevo = new Models.Usuario(tbx_Nombre.Text, tbx_Apellidos.Text, tbx_Sexo.Text, tbx_Pais.Text, tbx_Username.Text,
                tbx_Password.Text, tbx_Email.Text, tbx_PMethod.Text, (bool)cbk_Premium.IsChecked);

            XmlElement nodoUsuario = doc.CreateElement("Usuario");
            XmlAttribute nombre = doc.CreateAttribute("Nombre");
            nombre.Value = nuevo.Nombre;
            nodoUsuario.Attributes.Append(nombre);
            XmlAttribute ape = doc.CreateAttribute("Apellidos");
            ape.Value = nuevo.ape;
            nodoUsuario.Attributes.Append(ape);
            XmlAttribute sexo = doc.CreateAttribute("Sexo");
            sexo.Value = nuevo.sexo;
            nodoUsuario.Attributes.Append(sexo);
            XmlAttribute pais = doc.CreateAttribute("Pais");
            pais.Value = nuevo.pais;
            nodoUsuario.Attributes.Append(pais);
            XmlAttribute username = doc.CreateAttribute("Username");
            username.Value = nuevo.username;
            nodoUsuario.Attributes.Append(username);
            XmlAttribute password = doc.CreateAttribute("Password");
            password.Value = nuevo.contrasena;
            nodoUsuario.Attributes.Append(password);
            XmlAttribute email = doc.CreateAttribute("Email");
            email.Value = nuevo.email ;
            nodoUsuario.Attributes.Append(email);
            XmlAttribute metodopago = doc.CreateAttribute("Metodopago");
            metodopago.Value = nuevo.metodopago;
            nodoUsuario.Attributes.Append(metodopago);
            XmlAttribute premium = doc.CreateAttribute("Premium");
            premium.Value = nuevo.Premium.ToString();
            nodoUsuario.Attributes.Append(premium);

            return nodoUsuario;
        }
    }
}
