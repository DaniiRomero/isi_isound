﻿namespace MuMaps.Models
{
    public class SpotifyArtist
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public string Followers { get; set; }
        public string Popularity { get; set; }
    }
}
