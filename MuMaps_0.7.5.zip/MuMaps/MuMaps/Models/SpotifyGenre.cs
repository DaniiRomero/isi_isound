﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MuMaps.Models
{
    public class SpotifyGenre
    {
        public string id { get; set; }
        public string nombre { get; set; }
        public string url { get; set; }
    }
}
