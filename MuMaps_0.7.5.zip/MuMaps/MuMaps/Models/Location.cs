﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MuMaps.Models
{
    public class Location
    {
        public string title { get; set; }
        public double lat { get; set; }
        public double lng { get; set; }
    }
}
